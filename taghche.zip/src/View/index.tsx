export { default as Home } from './PagesView/HomePage';
